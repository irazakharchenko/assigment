package ua.edu.ucu.tempseries;

public class TempSummaryStatistics {
    
}
